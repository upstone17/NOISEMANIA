#include "ofApp.h"
#include<Windows.h>
#include<vector>

double height, width;
double lane_width,lane_gap;

int seni;
int combo;
int max_combo;
int score;
int just;
int miss;


bool coolflag_1;
bool clap_flag;
bool star_flag;
bool p;
bool m;
bool j_p;
bool j_m;

long long GetTime, GameStart;
long long now, tap;

double PSB_T,star_T;
double a1, a2, a3, b1, b2;

int fall_speed = 0;

vector<unsigned int>fumen(0);
vector<int>star_x(7);
vector<int>star_y(7);
vector<double>fumen_y(50);
vector<int>fumen_x(50);
vector<bool>combo_judge(50,true);

//--------------------------------------------------------------
void ofApp::setup(){
	
	//�ϐ��̐錾
	height = ofGetHeight();
	width = ofGetWidth();

	seni = 0;                                       ////////////////////////////////�����ɑJ�ڂ̂����//////////////////////////////////
	combo = 0;
	max_combo = 0;
	score = 0;
	just = 0;
	miss = 0;

	lane_width = width / 6;
	lane_gap = 10;

	GetTime = 0;
	GameStart = 0;
	now = 0;
	tap = 0;
	
	fall_speed = 5;



	coolflag_1 = false;
	clap_flag = false;
	star_flag = true;
	p = false;
	m = false;
	j_p = false;
	j_m = false;

	PSB_T = 0;
	star_T = 0;
	a1 = 0;
	a2 = 0;
	a3 = 0;
	b1 = 0;


	//���ʓǂݍ���

	fumen_y = { 3836,5320,6872,8336,9887,11439,12937,14453,15953,17502,19036,20520,22025,23619,25086,26586,28137,29652,31202,32654,34173,35769,37304,
		38785,40220,41819,43303,44836,46353,47886,49402,50919,52387,53937,55437,57004,58487,60036,61521,63069,64603,66120,67669,69169,70670,72169,73719,75220,76653,78536 };

	for (int i = 0; i < fumen_y.size(); i++) {


		int x = 0;
		x = ofRandom(0, 99);
		x %= 3;
		if (x == 0)fumen_x[i] = (width / 2);
		else if (x == 1)fumen_x[i] = (width / 2) + lane_width;
		else if (x == 2)fumen_x[i] = (width / 2) + lane_width * 2;
		//std::cout << fumen_x[i] << std::endl;    �o�̓`�F�b�N�p
	}


	//�ݒ�
	ofBackground(0,0,0);


	//���[�h
	ofTrueTypeFontSettings settings("BitCheese10(sRB).TTF",50);
	settings.addRanges(ofAlphabet::Latin);
	press_start.load(settings);

	ofTrueTypeFontSettings settings1("BitCheese10(sRB).TTF", 65);
	settings1.addRanges(ofAlphabet::Latin);
	BN_button.load(settings1);

	ofTrueTypeFontSettings setting2("BitCheese10(sRB).TTF", 75);
	setting2.addRanges(ofAlphabet::Latin);
	sub_title.load(setting2);

	ofTrueTypeFontSettings settings3("BitCheese10(sRB).TTF", 125);
	settings3.addRanges(ofAlphabet::Latin);
	Result.load(settings3);

	title.load("game_title.png");
	stars.load("star.png");
	shining.load("shinig_star_jacket.jpg");
	HowToPlay.load("how_to_play.png");
	otoge.load("shining_star.mp3");
	effect_clap.load("clap.wav");



	//�^�C�g���̐��̈ʒu���w��
	while (true) {
		star_flag = true;
		//���̍��W��z��ɓ����
		for (int j = 0; j < 7; j++) {
			int x = 0;
			int y = 0;
			star_x[j] = ofRandom(0, 2000);
			star_y[j] = ofRandom(0, 350);
		}

		//�����d�Ȃ��Ă��Ȃ����`�F�b�N
		for (int i = 0; i < 7; i++) {
			for (int j = i + 1; j < 7; j++) {
				int check_x = 0;
				int check_y = 0;
				check_x = abs(star_x[i] - star_x[j]);
				check_y = abs(star_y[i] - star_y[j]);
				if (check_x < 50 || check_y < 50) {
					star_flag = false;
				}
			}
		}

		if (star_flag)break;
	}



}

//--------------------------------------------------------------
void ofApp::update(){

	//���Ԍv���i�X�^�[�g���j
	GetTime=ofGetElapsedTimeMillis();


	//press start button�̓����x
	PSB_T = ofNoise(a1, a2, a3) * 255;
	a1 += 0.007;
	a2 += 0.007;
	a3 += 0.007;
	
	star_T = ofNoise(b1, b2) * 255;
	b1 += 0.04;
	b2 += 0.04;

	now = GetTime - GameStart;


	/*�e�X�g�p���Ƃŏ���*/
	//std::cout << GetTime << " " << seni << " " << fall_speed << " " << now << " " << 1275 - (fumen_y[49] / 16.0 * fall_speed) * 0.0001 * (fumen_y[49] - now) <<  std::endl;



	//�Q�[���I����̃��U���g�ւ̈ڍs
	if (GetTime - GameStart > 90000 && seni==3)seni++;

	//���ʌ��ؗp
	/*
		if (seni == 4) {
			for (int i = 0; i < fumen.size(); i++) {
				std::cout << fumen[i] << ",";
				if (i == fumen.size() - 1)std::cout << std::endl;
			}

			std::cout << 1275 - (fumen_y[0] / 16 * fall_speed) * 1 * (fumen_y[0] - now) << std::endl;
		}
	*/

	//MISS����p
	if (seni == 3) {
		for (int i = 0; i < fumen_y.size(); i++) {
			if (combo_judge[i]) {
			if ((1275 - (fumen_y[i] / 16 * fall_speed) * 0.0001 * (fumen_y[i] - now)) >= 1350) {

					miss++;
					combo = 0;
					combo_judge[i] = false;
					m = true;
					p = false;
				}


			}
		}
	}
		
	//cout << seni << endl;
}

//--------------------------------------------------------------
void ofApp::draw(){

	//��ʂP�i�^�C�g���j
	if (seni == 0) {
		ofSetColor(255, 255, 255);
		title.draw(400,300);
		

		ofSetColor(255, 255, 255, PSB_T);
		press_start.drawString("press�@�@�@�@�@space�@�@�@�@�@button", 450, 1100);

		for (int i = 0; i < 7; i++) {
			stars.draw(star_x[i], star_y[i]);
		}

	}

	//��ʂQ�i�Q�[���̗V�ѕ��j
	if (seni == 1) {

		//��ʕ\��
		ofSetColor(255, 255, 255);
		ofDrawRectangle(50, 1300, 300, 150);
		ofDrawRectangle(1650, 1300, 300, 150);
		ofSetColor(0, 0, 0);
		ofDrawRectangle(50+5, 1300+5, 300-10, 150-10);
		ofDrawRectangle(1650+5, 1300+5, 300-10, 150-10);

		ofSetColor(255,255,255);
		BN_button.drawString("BACK", 65, 1420);
		BN_button.drawString("NEXT", 1665, 1420);

		Result.drawString("How to Play", 70, 160);

		HowToPlay.draw(300, 200);

	}

	//��ʂR�i�y�ȏЉ�j
	if (seni == 2) {
		//��ʕ\��
		ofSetColor(255, 255, 255);
		ofDrawRectangle(50, 1300, 300, 150);
		ofDrawRectangle(1650, 1300, 300, 150);
		ofSetColor(0, 0, 0);
		ofDrawRectangle(50 + 5, 1300 + 5, 300 - 10, 150 - 10);
		ofDrawRectangle(1650 + 5, 1300 + 5, 300 - 10, 150 - 10);

		ofSetColor(255, 255, 255);
		ofDrawRectangle(700, 350, 750, 750);
		ofSetColor(0, 0, 0);
		ofDrawRectangle(705, 355, 740, 740);

		ofSetColor(255, 255, 255);
		BN_button.drawString("BACK", 65, 1420);
		BN_button.drawString("NEXT", 1665, 1420);

		Result.drawString("Music", 70, 160);

		sub_title.drawString("DIFFICULTY : ", 525, 1250);
		ofSetColor(0, 255, 0);
		sub_title.drawString("easy", 1375, 1250);

		ofSetColor(255, 255, 255);
		shining.draw(750, 400);


	}

	//��ʂS�i�Q�[����ʁj
	if (seni == 3) {

		//�w�i
		ofSetColor(120, 120, 120, 60);
		ofDrawRectangle(width / 2, 1200, width / 2, 150);

		ofSetColor(255, 255, 255);
		ofSetLineWidth(4);

		ofDrawLine(width / 2, 0, width / 2, height);
		ofDrawLine(width / 2 + lane_gap, 0, width / 2 +lane_gap, height);
		ofDrawLine(width / 2 + lane_width, 0, width / 2 +lane_width, height);
		ofDrawLine(width / 2 + lane_width + lane_gap, 0, width / 2 + lane_width + lane_gap, height);
		ofDrawLine(width / 2 + lane_width*2, 0, width / 2 + lane_width*2, height);
		ofDrawLine(width / 2 + lane_width*2 + lane_gap, 0, width / 2 + lane_width*2 + lane_gap, height);
		ofDrawLine(width, 0, width, height);
		ofDrawLine(width - lane_gap, 0, width - lane_gap, height);

		//����Ȃ�
		sub_title.drawString("COMBO",300, 200);
		sub_title.drawString(ofToString(combo), 300, 300);

		sub_title.drawString("SCORE", 300, 500);
		sub_title.drawString(ofToString(score), 300, 600);


		sub_title.drawString("Judgement", 150, 800);
		if (p) {
			ofSetColor(255, 255, 0);
			sub_title.drawString("JUST", 350, 950);
		}
		else if (m) {
			ofSetColor(255, 0, 255);
			sub_title.drawString("MISS", 350, 950);
		}


		ofSetColor(255, 255, 0);
		sub_title.drawString("Just", 100, 1200);
		ofSetColor(255, 255, 255);
		sub_title.drawString(ofToString(just), 600, 1200);

		ofSetColor(255, 0, 255);
		sub_title.drawString("Miss", 100, 1400);
		ofSetColor(255, 255, 255);
		sub_title.drawString(ofToString(miss), 600, 1400);

		
		//���ʍ��W
		for (int i = 0; i < fumen_y.size(); i++) {
			ofDrawRectangle(fumen_x[i], 1275 - (fumen_y[i] / 16 * fall_speed) * 0.0001 *(fumen_y[i] - now), lane_width, 75);
		}
	}

	//��ʂT�i���U���g�j
	if (seni == 4) {
		//�ʏ�
		ofSetColor(255, 255, 255);
		Result.drawString("Result", 650, 200);
		sub_title.drawString("combo", 450, 500);
		sub_title.drawString(ofToString(max_combo), 1350, 500);
		sub_title.drawString("score", 450, 700);
		sub_title.drawString(ofToString(score), 1350, 700);
		ofSetColor(255, 255, 0);
		sub_title.drawString("just", 450, 900);
		ofSetColor(255, 255, 255);
		sub_title.drawString(ofToString(just), 1350, 900);
		ofSetColor(255, 0, 255);
		if (miss == 0)ofSetColor(255, 255, 255);
		sub_title.drawString("miss", 450, 1100);
		ofSetColor(255, 255, 255);
		sub_title.drawString(ofToString(miss), 1350, 1100);

		//�t���R���{
		if (miss == 0) {
			ofSetColor(255, 255, 0);
			Result.drawString("FULL COMBO", 650, 1400);
		}

	}
	
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

	//�X�^�[�g���
	if (key == 32 && seni==0) {
		seni++;
	}

	//�Q�[����ʁA�N���b�v��
	if (clap_flag && key == 32 && seni == 3) {
		effect_clap.play();
	}


	//JUST����p
	for (int i = 0; i < fumen_y.size(); i++) {
		if (1200 <= (1275 - (fumen_y[i] / 16 * fall_speed) * 0.0001 * (fumen_y[i] - now)) && (1275 - (fumen_y[i] / 16 * fall_speed) * 0.0001 * (fumen_y[i] - now)) <= 1350 && fumen_x[i] <= mouseX && mouseX <= fumen_x[i] + lane_width && key == 32) {

			just++;
			combo++;
			if (combo >= max_combo)max_combo = combo;
			score += 100 * combo * 1.1;
			j_p = true;
			j_m = false;
			fumen_y[i] = 10000000;
			p = true;
			m = false;
		}
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){


	//��ʂQ����
	if (seni == 1 && coolflag_1==false) {
		if (button == 0 && 50 <= x && x <= 350 && 1300 <= y && y <= 1450)seni--;
		if (button == 0 && 1650 <= x && x <= 1950 && 1300 <= y && y <= 1450) {
			seni++;
			coolflag_1 = true;
		}
	}

	//��ʂR����
	if (seni == 2 && coolflag_1==false) {
		if (button == 0 && 50 <= x && x <= 350 && 1300 <= y && y <= 1450)seni--;

		//�v���X�^�[�g
		if (button == 0 && 1650 <= x && x <= 1950 && 1300 <= y && y <= 1450) {			
			seni++;
			
			//�Q�[����ʂւ̏���
			otoge.play();

			clap_flag = true;
			GameStart = ofGetElapsedTimeMillis();

			//������
			combo = 0;
			max_combo = 0;
			score = 0;
			just = 0;
			miss = 0;

		}
	}

	//��ʑJ�ڂ̃N�[���^�C��
	if (coolflag_1)coolflag_1 = false;

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}


